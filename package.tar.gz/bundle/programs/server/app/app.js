var require = meteorInstall({"imports":{"api":{"documents":{"server":{"publications.js":["meteor/meteor","../documents",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/documents/server/publications.js                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Documents;module.import('../documents',{"Documents":function(v){Documents=v}});
                                                                                                                     // 2
                                                                                                                     //
Meteor.publish('documents', function () {                                                                            // 4
  return Documents.find();                                                                                           // 4
});                                                                                                                  // 4
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"documents.js":["meteor/mongo","meteor/aldeed:simple-schema",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/documents/documents.js                                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({Documents:function(){return Documents}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});//import faker from 'faker';
                                                                                                                     // 2
                                                                                                                     // 3
//import { Factory } from 'meteor/dburles:factory';                                                                  //
                                                                                                                     //
var Documents = new Mongo.Collection('Documents');                                                                   // 6
                                                                                                                     //
Documents.schema = new SimpleSchema({                                                                                // 8
  title: {                                                                                                           // 9
    type: String,                                                                                                    // 10
    label: 'The title of the document.'                                                                              // 11
  }                                                                                                                  // 9
});                                                                                                                  // 8
                                                                                                                     //
Documents.attachSchema(Documents.schema);                                                                            // 15
                                                                                                                     //
/*Factory.define('document', Documents, {                                                                            //
  title: () => faker.hacker.phrase(),                                                                                //
});*/                                                                                                                //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["./documents","meteor/aldeed:simple-schema","meteor/mdg:validated-method",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/documents/methods.js                                                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({insertDocument:function(){return insertDocument},updateDocument:function(){return updateDocument},removeDocument:function(){return removeDocument}});var Documents;module.import('./documents',{"Documents":function(v){Documents=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     //
/*                                                                                                                   //
export const insertDocument = new ValidatedMethod({                                                                  //
  name: 'documents.insert',                                                                                          //
  validate: new SimpleSchema({                                                                                       //
    title: { type: String },                                                                                         //
  }).validator(),                                                                                                    //
  run(document) {                                                                                                    //
    Documents.insert(document);                                                                                      //
  },                                                                                                                 //
});                                                                                                                  //
*/                                                                                                                   //
                                                                                                                     //
var insertDocument = new ValidatedMethod({                                                                           // 17
  name: 'documents.insert',                                                                                          // 18
  validate: Documents.schema.validator(),                                                                            // 19
  run: function run(document) {                                                                                      // 20
    Documents.insert(document);                                                                                      // 21
  }                                                                                                                  // 22
});                                                                                                                  // 17
                                                                                                                     //
var updateDocument = new ValidatedMethod({                                                                           // 25
  name: 'documents.update',                                                                                          // 26
  validate: new SimpleSchema({                                                                                       // 27
    _id: { type: String },                                                                                           // 28
    'update.title': { type: String, optional: true }                                                                 // 29
  }).validator(),                                                                                                    // 27
  run: function run(_ref) {                                                                                          // 31
    var _id = _ref._id;                                                                                              // 31
    var update = _ref.update;                                                                                        // 31
                                                                                                                     //
    Documents.update(_id, { $set: update });                                                                         // 32
  }                                                                                                                  // 33
});                                                                                                                  // 25
                                                                                                                     //
var removeDocument = new ValidatedMethod({                                                                           // 36
  name: 'documents.remove',                                                                                          // 37
  validate: new SimpleSchema({                                                                                       // 38
    _id: { type: String }                                                                                            // 39
  }).validator(),                                                                                                    // 38
  run: function run(_ref2) {                                                                                         // 41
    var _id = _ref2._id;                                                                                             // 41
                                                                                                                     //
    Documents.remove(_id);                                                                                           // 42
  }                                                                                                                  // 43
});                                                                                                                  // 36
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"evenements":{"server":{"publications.js":["meteor/meteor","../evenements",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/evenements/server/publications.js                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Evenements;module.import('../evenements',{"Evenements":function(v){Evenements=v}});
                                                                                                                     // 2
                                                                                                                     //
Meteor.publish('evenements', function () {                                                                           // 4
  return Evenements.find();                                                                                          // 4
});                                                                                                                  // 4
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"evenements.js":["meteor/aldeed:simple-schema",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/evenements/evenements.js                                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({Evenements:function(){return Evenements}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});
                                                                                                                     //
var Evenements = new Meteor.Collection('evenements');                                                                // 3
                                                                                                                     //
Evenements.schema = new SimpleSchema({                                                                               // 5
  "titre": {                                                                                                         // 6
    type: String,                                                                                                    // 7
    label: "Le titre de l'activité"                                                                                  // 8
  },                                                                                                                 // 6
  "start": {                                                                                                         // 10
    type: Date,                                                                                                      // 11
    label: "Date à laquelle l'activité est prévue"                                                                   // 12
  },                                                                                                                 // 10
  "end": {                                                                                                           // 14
    type: Date,                                                                                                      // 15
    label: "Date à laquelle l'activité se termine"                                                                   // 16
  },                                                                                                                 // 14
  "allDay": {                                                                                                        // 18
    type: Boolean,                                                                                                   // 19
    label: "Evénement à la journée"                                                                                  // 20
  },                                                                                                                 // 18
  "nbJours": {                                                                                                       // 22
    type: Number,                                                                                                    // 23
    label: "le nombre de jours de l'activité si en jours entiers"                                                    // 24
  },                                                                                                                 // 22
  "nbTotalPlaces": {                                                                                                 // 26
    type: Number,                                                                                                    // 27
    label: "Le nombre de places total disponibles"                                                                   // 28
  },                                                                                                                 // 26
  "type": {                                                                                                          // 30
    type: String,                                                                                                    // 31
    label: "Quelle structure propose l'activité ?",                                                                  // 32
    allowedValues: ['La-Bonne-Fabrique', 'Le-Coworking', 'La-brasserie', 'La-Salle-des-Machines', 'Autres']          // 33
  },                                                                                                                 // 30
  "places": {                                                                                                        // 35
    type: Number,                                                                                                    // 36
    label: "Le nombre de places de l'activité",                                                                      // 37
    optional: true                                                                                                   // 38
  },                                                                                                                 // 35
  "lieu": {                                                                                                          // 40
    type: String,                                                                                                    // 41
    label: "Lieu où se déroule l'évènement"                                                                          // 42
  },                                                                                                                 // 40
  "description": {                                                                                                   // 44
    type: String,                                                                                                    // 45
    label: "Description de l'évènement"                                                                              // 46
  },                                                                                                                 // 44
  "creneaux": {                                                                                                      // 48
    type: [Object],                                                                                                  // 49
    label: "Horaire, nombre de places et d'inscrits",                                                                // 50
    optional: true                                                                                                   // 51
  },                                                                                                                 // 48
  "creneaux.$._id": {                                                                                                // 53
    type: String,                                                                                                    // 54
    label: 'id du creneaux'                                                                                          // 55
  },                                                                                                                 // 53
  "creneaux.$.horaire": {                                                                                            // 57
    type: String,                                                                                                    // 58
    label: "Le créneau horaire"                                                                                      // 59
  },                                                                                                                 // 57
  "creneaux.$.places": {                                                                                             // 61
    type: Number,                                                                                                    // 62
    label: "Le nombre de places dans le créneau"                                                                     // 63
  },                                                                                                                 // 61
  "creneaux.$.inscrits": {                                                                                           // 65
    type: [String],                                                                                                  // 66
    label: "La table des inscrits",                                                                                  // 67
    optional: true                                                                                                   // 68
  },                                                                                                                 // 65
  "inscription": {                                                                                                   // 70
    type: Boolean,                                                                                                   // 71
    label: "Inscriptions nécessaires ?",                                                                             // 72
    optional: true                                                                                                   // 73
  },                                                                                                                 // 70
  "lienImage": {                                                                                                     // 75
    type: String,                                                                                                    // 76
    label: "Lien de l'image pour l'accueil",                                                                         // 77
    optional: true                                                                                                   // 78
  }                                                                                                                  // 75
});                                                                                                                  // 5
                                                                                                                     //
Evenements.attachSchema(Evenements.schema);                                                                          // 82
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["./evenements","meteor/aldeed:simple-schema","meteor/mdg:validated-method",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/evenements/methods.js                                                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({insertEvenement:function(){return insertEvenement},removeEvenement:function(){return removeEvenement},updateEvenement:function(){return updateEvenement},updateInscrits:function(){return updateInscrits}});var Evenements;module.import('./evenements',{"Evenements":function(v){Evenements=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     //
var insertEvenement = new ValidatedMethod({                                                                          // 5
  name: 'evenements.insert',                                                                                         // 6
  validate: Evenements.schema.validator(),                                                                           // 7
  run: function run(evenement) {                                                                                     // 8
    Evenements.insert(evenement);                                                                                    // 9
  }                                                                                                                  // 10
});                                                                                                                  // 5
                                                                                                                     //
var removeEvenement = new ValidatedMethod({                                                                          // 13
  name: 'evenements.remove',                                                                                         // 14
  validate: new SimpleSchema({                                                                                       // 15
    _id: { type: String }                                                                                            // 16
  }).validator(),                                                                                                    // 15
  run: function run(_ref) {                                                                                          // 18
    var _id = _ref._id;                                                                                              // 18
                                                                                                                     //
    Evenements.remove(_id);                                                                                          // 19
  }                                                                                                                  // 20
});                                                                                                                  // 13
                                                                                                                     //
var updateEvenement = new ValidatedMethod({                                                                          // 23
  name: 'evenements.update',                                                                                         // 24
  validate: new SimpleSchema({                                                                                       // 25
    evenementId: {                                                                                                   // 26
      type: String                                                                                                   // 27
    },                                                                                                               // 26
    update: {                                                                                                        // 29
      type: Object,                                                                                                  // 30
      blackbox: true                                                                                                 // 31
    }                                                                                                                // 29
  }).validator(),                                                                                                    // 25
  run: function run(_ref2) {                                                                                         // 34
    var evenementId = _ref2.evenementId;                                                                             // 34
    var update = _ref2.update;                                                                                       // 34
                                                                                                                     //
    Evenements.update(evenementId, { $set: update });                                                                // 35
  }                                                                                                                  // 36
});                                                                                                                  // 23
                                                                                                                     //
var updateInscrits = new ValidatedMethod({                                                                           // 39
  name: 'evenements.updateInscrits',                                                                                 // 40
  validate: new SimpleSchema({                                                                                       // 41
    evenementId: {                                                                                                   // 42
      type: String                                                                                                   // 43
    },                                                                                                               // 42
    "update.creneaux": {                                                                                             // 45
      type: [Object]                                                                                                 // 46
    },                                                                                                               // 45
    "update.creneaux.$._id": {                                                                                       // 48
      type: String                                                                                                   // 49
    },                                                                                                               // 48
    "update.creneaux.$.horaire": {                                                                                   // 51
      type: String                                                                                                   // 52
    },                                                                                                               // 51
    "update.creneaux.$.places": {                                                                                    // 54
      type: Number                                                                                                   // 55
    },                                                                                                               // 54
    "update.creneaux.$.inscrits": {                                                                                  // 57
      type: [String]                                                                                                 // 58
    }                                                                                                                // 57
  }).validator(),                                                                                                    // 41
  run: function run(_ref3) {                                                                                         // 61
    var evenementId = _ref3.evenementId;                                                                             // 61
    var update = _ref3.update;                                                                                       // 61
                                                                                                                     //
    Evenements.update(evenementId, { $set: update });                                                                // 62
  }                                                                                                                  // 63
});                                                                                                                  // 39
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"images":{"server":{"publications.js":["meteor/meteor","../images.js",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/images/server/publications.js                                                                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Images;module.import('../images.js',{"Images":function(v){Images=v}});
                                                                                                                     // 2
                                                                                                                     //
//Images.denyClient();                                                                                               //
/*                                                                                                                   //
Meteor.publish('files.images.all', function () {                                                                     //
    return Images.find().cursor;                                                                                     //
  });*/                                                                                                              //
                                                                                                                     //
Meteor.publish('images', function () {                                                                               // 11
    return Images.find().cursor;                                                                                     // 11
});                                                                                                                  // 11
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"images.js":["meteor/ostrio:files","./methods","meteor/meteor","fs-plus",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/images/images.js                                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({Images:function(){return Images},imagesPath:function(){return imagesPath}});var FilesCollection;module.import("meteor/ostrio:files",{"FilesCollection":function(v){FilesCollection=v}});var newVersion;module.import('./methods',{"newVersion":function(v){newVersion=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     //
var fs = require('fs-plus');                                                                                         // 6
                                                                                                                     //
var getImageFileSize = function getImageFileSize(file) {                                                             // 9
  return when.promise(function (resolve, reject) {                                                                   // 10
                                                                                                                     //
    gm(file).filesize(function (err, size) {                                                                         // 12
      if (err) {                                                                                                     // 13
        reject(err);                                                                                                 // 14
      } else {                                                                                                       // 15
        resolve(size);                                                                                               // 16
      }                                                                                                              // 17
    });                                                                                                              // 18
  });                                                                                                                // 20
};                                                                                                                   // 21
                                                                                                                     //
var Images = new FilesCollection({                                                                                   // 23
  storagePath: '/data/assets/images',                                                                                // 24
  collectionName: 'Images',                                                                                          // 25
  allowClientCode: false, // Disallow remove files from Client                                                       // 26
  onBeforeUpload: function onBeforeUpload(file) {                                                                    // 27
    // Allow upload files under 10MB, and only in png/jpg/jpeg formats                                               //
    if (file.size <= 10485760 && /png|jpg|jpeg|gif/i.test(file.extension)) {                                         // 29
      return true;                                                                                                   // 30
    } else {                                                                                                         // 31
      return 'Les fichiers doivent être inférieur à 10 MB.';                                                         // 32
    }                                                                                                                // 33
  },                                                                                                                 // 34
  onAfterUpload: function onAfterUpload(file) {                                                                      // 35
                                                                                                                     //
    //dimensions image finale                                                                                        //
    var sizes = [{ size: 190, ratio: 1 }, { size: 120, ratio: 1 }];                                                  // 38
    //définition des chemins                                                                                         //
    var cheminInitial = file.path;                                                                                   // 40
    var update = file.versions;                                                                                      // 41
    var fileId = file._id;                                                                                           // 42
    var self = this;                                                                                                 // 43
                                                                                                                     //
    sizes.map(function (taille) {                                                                                    // 45
      var size = taille.size;                                                                                        // 46
      var ratio = taille.ratio;                                                                                      // 47
                                                                                                                     //
      var cheminCopie = self.storagePath + "/" + file._id + "-" + size.toString() + "." + file.extension;            // 49
      // taille de l'image                                                                                           //
      var imgInitialeSize;                                                                                           // 51
      var imgInitiale = gm(cheminInitial);                                                                           // 52
      imgInitialeSize = Meteor.wrapAsync(imgInitiale.size, imgInitiale);                                             // 53
      var taille;                                                                                                    // 54
      try {                                                                                                          // 55
        taille = imgInitialeSize();                                                                                  // 56
      } catch (e) {                                                                                                  // 57
        console.log('Error:');                                                                                       // 58
        console.log(e);                                                                                              // 59
      }                                                                                                              // 60
                                                                                                                     //
      var largeur = taille.width;                                                                                    // 63
      var hauteur = taille.height;                                                                                   // 64
      var ratioInitial = largeur / hauteur;                                                                          // 65
                                                                                                                     //
      var largeurCropped = largeur;                                                                                  // 67
      var hauteurCropped = hauteur;                                                                                  // 68
      var cropX = 0;                                                                                                 // 69
      var cropY = 0;                                                                                                 // 70
      if (ratioInitial > ratio) {                                                                                    // 71
        largeurCropped = hauteur * ratio;                                                                            // 72
        cropX = (largeur - largeurCropped) / 2;                                                                      // 73
      } else if (ratioInitial < ratio) {                                                                             // 74
        hauteurCropped = largeur / ratio;                                                                            // 75
        cropY = (hauteur - hauteurCropped) / 2;                                                                      // 76
      }                                                                                                              // 77
                                                                                                                     //
      var imageCopie = gm(cheminInitial).crop(largeurCropped, hauteurCropped, cropX, cropY).resize(size, size);      // 79
                                                                                                                     //
      var writeCopie;                                                                                                // 83
      var imgResizeCrop = Meteor.wrapAsync(imageCopie.write, imageCopie);                                            // 84
      try {                                                                                                          // 85
        writeCopie = imgResizeCrop(cheminCopie);                                                                     // 86
      } catch (e) {                                                                                                  // 87
        console.log('Error:');                                                                                       // 88
        console.log(e);                                                                                              // 89
      }                                                                                                              // 90
                                                                                                                     //
      var tailleFichier = gm(cheminCopie);                                                                           // 92
      var imgCopieFilesize = Meteor.wrapAsync(tailleFichier.filesize, tailleFichier);                                // 93
                                                                                                                     //
      var tailleFichierCopie;                                                                                        // 95
      try {                                                                                                          // 96
        tailleFichierCopie = imgCopieFilesize();                                                                     // 97
      } catch (e) {                                                                                                  // 98
        console.log('Error:');                                                                                       // 99
        console.log(e);                                                                                              // 100
      }                                                                                                              // 101
                                                                                                                     //
      var sizeText = size.toString();                                                                                // 103
      var versionUpdate = "taille" + sizeText;                                                                       // 104
                                                                                                                     //
      update[versionUpdate] = {                                                                                      // 106
        path: cheminCopie,                                                                                           // 107
        size: tailleFichierCopie,                                                                                    // 108
        type: file.type,                                                                                             // 109
        extension: file.extension,                                                                                   // 110
        meta: { width: size, ratio: ratio }                                                                          // 111
      };                                                                                                             // 106
    });                                                                                                              // 114
                                                                                                                     //
    newVersion.call({ fileId: fileId, update: update }, function (error) {                                           // 117
      if (error) {                                                                                                   // 118
        console.log(error);                                                                                          // 119
      } else {                                                                                                       // 120
        console.log('done');                                                                                         // 121
      }                                                                                                              // 122
    });                                                                                                              // 123
  },                                                                                                                 // 125
  downloadCallback: function downloadCallback(fileObj) {                                                             // 126
    //   if @params?.query.download is 'true'                                                                        //
    //  Collections.files.collection.update fileObj._id, $inc: 'meta.downloads': 1                                   //
    return true;                                                                                                     // 129
  }                                                                                                                  // 130
                                                                                                                     //
});                                                                                                                  // 23
                                                                                                                     //
var imagesPath = Images.storagePath;                                                                                 // 134
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["./images","meteor/aldeed:simple-schema","meteor/mdg:validated-method",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/images/methods.js                                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({supprimeImage:function(){return supprimeImage},newVersion:function(){return newVersion}});var Images;module.import('./images',{"Images":function(v){Images=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     //
var supprimeImage = new ValidatedMethod({                                                                            // 5
  name: 'images.supprime',                                                                                           // 6
  validate: new SimpleSchema({                                                                                       // 7
    id: { type: String }                                                                                             // 8
  }).validator(),                                                                                                    // 7
  run: function run(_ref) {                                                                                          // 10
    var id = _ref.id;                                                                                                // 10
                                                                                                                     //
    Images.remove(id);                                                                                               // 11
  }                                                                                                                  // 12
});                                                                                                                  // 5
                                                                                                                     //
var newVersion = new ValidatedMethod({                                                                               // 15
  name: 'images.subversion',                                                                                         // 16
  validate: new SimpleSchema({                                                                                       // 17
    fileId: { type: String },                                                                                        // 18
    update: { type: Object, blackbox: true }                                                                         // 19
                                                                                                                     //
  }).validator(),                                                                                                    // 17
  run: function run(_ref2) {                                                                                         // 22
    var fileId = _ref2.fileId;                                                                                       // 22
    var update = _ref2.update;                                                                                       // 22
                                                                                                                     //
    //const versions = Images.findOne({id}).fetch().versions;                                                        //
                                                                                                                     //
    Images.update(fileId, { $set: { versions: update } });                                                           // 25
  }                                                                                                                  // 26
});                                                                                                                  // 15
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"users":{"server":{"publications.js":["meteor/meteor","meteor/alanning:roles",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/users/server/publications.js                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Roles;module.import('meteor/alanning:roles',{"Roles":function(v){Roles=v}});
                                                                                                                     // 2
                                                                                                                     //
Meteor.publish('utilisateurs', function () {                                                                         // 4
  return Meteor.users.find({}, { fields: { 'profile': 1, 'services': 1, 'emails': 1, 'reglageService': 1, 'adhesionFamille': 1, 'famille': 1, 'roles': 1 } });
});                                                                                                                  // 6
                                                                                                                     //
console.log(process.env.MAIL_URL);                                                                                   // 8
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"methods.js":["./users","meteor/aldeed:simple-schema","meteor/mdg:validated-method","meteor/alanning:roles",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/users/methods.js                                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({updateProfile:function(){return updateProfile},updateReglageService:function(){return updateReglageService},ajoutMembreFamille:function(){return ajoutMembreFamille},updateFamille:function(){return updateFamille},updateRoles:function(){return updateRoles}});var Users;module.import('./users',{"Users":function(v){Users=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});var Roles;module.import('meteor/alanning:roles',{"Roles":function(v){Roles=v}});
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     // 4
                                                                                                                     //
var updateProfile = new ValidatedMethod({                                                                            // 6
  name: 'user.updateProfile',                                                                                        // 7
  validate: new SimpleSchema({                                                                                       // 8
    usereId: {                                                                                                       // 9
      type: String                                                                                                   // 10
    },                                                                                                               // 9
    update: {                                                                                                        // 12
      type: Object                                                                                                   // 13
    },                                                                                                               // 12
    'update.profile': {                                                                                              // 15
      type: Object                                                                                                   // 16
    },                                                                                                               // 15
    'update.profile.nom': {                                                                                          // 18
      type: String                                                                                                   // 19
    },                                                                                                               // 18
    'update.profile.prenom': {                                                                                       // 21
      type: String                                                                                                   // 22
    },                                                                                                               // 21
    'update.emails': {                                                                                               // 24
      type: Array                                                                                                    // 25
    },                                                                                                               // 24
    "update.emails.$": {                                                                                             // 27
      type: Object                                                                                                   // 28
    },                                                                                                               // 27
    "update.emails.$.address": {                                                                                     // 30
      type: String,                                                                                                  // 31
      regEx: SimpleSchema.RegEx.Email                                                                                // 32
    },                                                                                                               // 30
    "update.emails.$.verified": {                                                                                    // 34
      type: Boolean                                                                                                  // 35
    },                                                                                                               // 34
    "update.adhesionFamille": {                                                                                      // 37
      type: Boolean                                                                                                  // 38
    },                                                                                                               // 37
    "update.famille": {                                                                                              // 40
      type: [Object]                                                                                                 // 41
    },                                                                                                               // 40
    "update.reglageService": {                                                                                       // 43
      type: Boolean                                                                                                  // 44
    },                                                                                                               // 43
    "update.roles": {                                                                                                // 46
      type: [String]                                                                                                 // 47
    }                                                                                                                // 46
  }).validator(),                                                                                                    // 8
  run: function run(_ref) {                                                                                          // 50
    var usereId = _ref.usereId;                                                                                      // 50
    var update = _ref.update;                                                                                        // 50
                                                                                                                     //
    Users.update(usereId, { $set: update });                                                                         // 51
  }                                                                                                                  // 52
});                                                                                                                  // 6
                                                                                                                     //
var updateReglageService = new ValidatedMethod({                                                                     // 55
  name: 'user.updateReglageProfile',                                                                                 // 56
  validate: new SimpleSchema({                                                                                       // 57
    userId: {                                                                                                        // 58
      type: String                                                                                                   // 59
    },                                                                                                               // 58
    'update.reglageService': {                                                                                       // 61
      type: Boolean                                                                                                  // 62
    }                                                                                                                // 61
  }).validator(),                                                                                                    // 57
  run: function run(_ref2) {                                                                                         // 65
    var userId = _ref2.userId;                                                                                       // 65
    var update = _ref2.update;                                                                                       // 65
                                                                                                                     //
    Users.update(userId, { $set: update });                                                                          // 66
  }                                                                                                                  // 67
});                                                                                                                  // 55
                                                                                                                     //
var ajoutMembreFamille = new ValidatedMethod({                                                                       // 70
  name: 'user.ajoutMembreFamille',                                                                                   // 71
  validate: new SimpleSchema({                                                                                       // 72
    "userId": {                                                                                                      // 73
      type: String,                                                                                                  // 74
      optional: true                                                                                                 // 75
    },                                                                                                               // 73
    "update.famille": {                                                                                              // 77
      type: Array,                                                                                                   // 78
      optional: true                                                                                                 // 79
    },                                                                                                               // 77
                                                                                                                     //
    "update.famille.$": {                                                                                            // 82
      type: Object,                                                                                                  // 83
      optional: true                                                                                                 // 84
    },                                                                                                               // 82
    "update.famille.$._id": {                                                                                        // 86
      type: String                                                                                                   // 87
    },                                                                                                               // 86
    "update.famille.$.nom": {                                                                                        // 89
      type: String,                                                                                                  // 90
      optional: true                                                                                                 // 91
    },                                                                                                               // 89
    "update.famille.$.prenom": {                                                                                     // 93
      type: String,                                                                                                  // 94
      optional: true                                                                                                 // 95
    },                                                                                                               // 93
    "update.famille.$.age": {                                                                                        // 97
      type: Date,                                                                                                    // 98
      optional: true                                                                                                 // 99
    },                                                                                                               // 97
    "update.famille.$.inscriptions": {                                                                               // 101
      type: [String],                                                                                                // 102
      optional: true                                                                                                 // 103
    }                                                                                                                // 101
  }).validator(),                                                                                                    // 72
  run: function run(_ref3) {                                                                                         // 106
    var userId = _ref3.userId;                                                                                       // 106
    var update = _ref3.update;                                                                                       // 106
                                                                                                                     //
    Users.update(userId, { $set: update });                                                                          // 107
  }                                                                                                                  // 108
});                                                                                                                  // 70
                                                                                                                     //
var updateFamille = new ValidatedMethod({                                                                            // 112
  name: 'user.updateFamille',                                                                                        // 113
  validate: new SimpleSchema({                                                                                       // 114
    userId: {                                                                                                        // 115
      type: String                                                                                                   // 116
    },                                                                                                               // 115
    update: {                                                                                                        // 118
      type: Object                                                                                                   // 119
    },                                                                                                               // 118
    'update.famille': {                                                                                              // 121
      type: [Object]                                                                                                 // 122
    },                                                                                                               // 121
    'update.famille.$._id': {                                                                                        // 124
      type: String                                                                                                   // 125
    },                                                                                                               // 124
    'update.famille.$.prenom': {                                                                                     // 127
      type: String,                                                                                                  // 128
      optional: true                                                                                                 // 129
    },                                                                                                               // 127
    'update.famille.$.nom': {                                                                                        // 131
      type: String,                                                                                                  // 132
      optional: true                                                                                                 // 133
    },                                                                                                               // 131
    'update.famille.$.age': {                                                                                        // 135
      type: Date,                                                                                                    // 136
      optional: true                                                                                                 // 137
    },                                                                                                               // 135
    'update.famille.$.inscriptions': {                                                                               // 139
      type: [String],                                                                                                // 140
      optional: true                                                                                                 // 141
    }                                                                                                                // 139
  }).validator(),                                                                                                    // 114
  run: function run(_ref4) {                                                                                         // 144
    var userId = _ref4.userId;                                                                                       // 144
    var update = _ref4.update;                                                                                       // 144
                                                                                                                     //
    Users.update(userId, { $set: update });                                                                          // 145
  }                                                                                                                  // 146
});                                                                                                                  // 112
                                                                                                                     //
var updateRoles = new ValidatedMethod({                                                                              // 149
  name: 'user.updateRoles',                                                                                          // 150
  validate: new SimpleSchema({                                                                                       // 151
    userId: {                                                                                                        // 152
      type: String                                                                                                   // 153
    },                                                                                                               // 152
    newRoles: {                                                                                                      // 155
      type: [String]                                                                                                 // 156
    }                                                                                                                // 155
  }).validator(),                                                                                                    // 151
  run: function run(_ref5) {                                                                                         // 159
    var userId = _ref5.userId;                                                                                       // 159
    var newRoles = _ref5.newRoles;                                                                                   // 159
                                                                                                                     //
    Roles.setUserRoles(userId, newRoles);                                                                            // 160
  }                                                                                                                  // 161
});                                                                                                                  // 149
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"users.js":["meteor/meteor","meteor/aldeed:simple-schema",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/users/users.js                                                                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({Users:function(){return Users}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});
                                                                                                                     // 2
                                                                                                                     //
var Users = Meteor.users;                                                                                            // 4
                                                                                                                     //
Users.UserProfile = new SimpleSchema({                                                                               // 6
    prenom: {                                                                                                        // 7
        type: String,                                                                                                // 8
        optional: true                                                                                               // 9
    },                                                                                                               // 7
    nom: {                                                                                                           // 11
        type: String,                                                                                                // 12
        optional: true                                                                                               // 13
    },                                                                                                               // 11
    dateAdhesion: {                                                                                                  // 15
        type: Date,                                                                                                  // 16
        optional: true                                                                                               // 17
    }                                                                                                                // 15
});                                                                                                                  // 6
                                                                                                                     //
Users.Famille = new SimpleSchema({                                                                                   // 21
    _id: {                                                                                                           // 22
        type: String                                                                                                 // 23
    },                                                                                                               // 22
    prenom: {                                                                                                        // 25
        type: String,                                                                                                // 26
        optional: true                                                                                               // 27
    },                                                                                                               // 25
    nom: {                                                                                                           // 29
        type: String,                                                                                                // 30
        optional: true                                                                                               // 31
    },                                                                                                               // 29
    age: {                                                                                                           // 33
        type: Date,                                                                                                  // 34
        optional: true                                                                                               // 35
    },                                                                                                               // 33
    inscriptions: {                                                                                                  // 37
        type: [String],                                                                                              // 38
        optional: true                                                                                               // 39
    }                                                                                                                // 37
});                                                                                                                  // 21
                                                                                                                     //
Users.User = new SimpleSchema({                                                                                      // 43
    username: {                                                                                                      // 44
        type: String,                                                                                                // 45
        // For accounts-password, either emails or username is required, but not both. It is OK to make this         //
        // optional here because the accounts-password package does its own validation.                              //
        // Third-party login packages may not require either. Adjust this schema as necessary for your usage.        //
        optional: true                                                                                               // 49
    },                                                                                                               // 44
    emails: {                                                                                                        // 51
        type: Array,                                                                                                 // 52
        // For accounts-password, either emails or username is required, but not both. It is OK to make this         //
        // optional here because the accounts-password package does its own validation.                              //
        // Third-party login packages may not require either. Adjust this schema as necessary for your usage.        //
        optional: true                                                                                               // 56
    },                                                                                                               // 51
    "emails.$": {                                                                                                    // 58
        type: Object                                                                                                 // 59
    },                                                                                                               // 58
    "emails.$.address": {                                                                                            // 61
        type: String,                                                                                                // 62
        regEx: SimpleSchema.RegEx.Email                                                                              // 63
    },                                                                                                               // 61
    "emails.$.verified": {                                                                                           // 65
        type: Boolean                                                                                                // 66
    },                                                                                                               // 65
    createdAt: {                                                                                                     // 68
        type: Date                                                                                                   // 69
    },                                                                                                               // 68
    profile: {                                                                                                       // 71
        type: Users.UserProfile,                                                                                     // 72
        optional: true                                                                                               // 73
    },                                                                                                               // 71
    // Make sure this services field is in your schema if you're using any of the accounts packages                  //
    services: {                                                                                                      // 76
        type: Object,                                                                                                // 77
        optional: true,                                                                                              // 78
        blackbox: true                                                                                               // 79
    },                                                                                                               // 76
    roles: {                                                                                                         // 81
        type: [String],                                                                                              // 82
        optional: true,                                                                                              // 83
        blackbox: true                                                                                               // 84
    },                                                                                                               // 81
    reglageService: {                                                                                                // 86
        type: Boolean,                                                                                               // 87
        optional: true                                                                                               // 88
    },                                                                                                               // 86
    //La table des id des activités passées et à venir auxquelles l'utilisateur s'est inscrit                        //
    inscriptions: {                                                                                                  // 91
        type: [String],                                                                                              // 92
        optional: true                                                                                               // 93
    },                                                                                                               // 91
    adhesionFamille: {                                                                                               // 95
        type: Boolean,                                                                                               // 96
        optional: true                                                                                               // 97
    },                                                                                                               // 95
    famille: {                                                                                                       // 99
        type: [Users.Famille],                                                                                       // 100
        optional: true                                                                                               // 101
    }                                                                                                                // 99
});                                                                                                                  // 43
                                                                                                                     //
Meteor.users.attachSchema(Users.User);                                                                               // 105
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"startup":{"server":{"accounts":{"email-templates.js":["meteor/accounts-base",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/accounts/email-templates.js                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});                             // 1
                                                                                                                     //
var name = 'La Bonne fabrique';                                                                                      // 3
var email = '<atelier@labonnefabrique.fr>';                                                                          // 4
var from = name + ' ' + email;                                                                                       // 5
var emailTemplates = Accounts.emailTemplates;                                                                        // 6
                                                                                                                     //
emailTemplates.siteName = name;                                                                                      // 8
emailTemplates.from = from;                                                                                          // 9
                                                                                                                     //
emailTemplates.resetPassword = {                                                                                     // 11
  subject: function subject() {                                                                                      // 12
    return '[' + name + '] Changement du mot de passe';                                                              // 13
  },                                                                                                                 // 14
  text: function text(user, url) {                                                                                   // 15
    var userEmail = user.emails[0].address;                                                                          // 16
    var urlWithoutHash = url.replace('#/', '');                                                                      // 17
                                                                                                                     //
    return 'Un changement de mot de passe a été demandé pour ce compte, lié à cette adresse mail (' + userEmail + '). Pour changer de mot de passe, cliquer sur le lien suivant :\n    \n' + urlWithoutHash + '\n\n Si vous n\'avez pas demandé à changer de mot de passe, merci d\'ignorer ce mail. Si vous pensez qu\'il y a un problème, merci de nous contacter à\n    ' + email + '.';
  }                                                                                                                  // 22
};                                                                                                                   // 11
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"api.js":["../../api/documents/methods.js","../../api/documents/server/publications.js","../../api/evenements/methods.js","../../api/evenements/server/publications.js","../../api/users/server/publications.js","../../api/users/methods.js","../../api/images/server/publications.js","../../api/images/methods.js",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/api.js                                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.import('../../api/documents/methods.js');module.import('../../api/documents/server/publications.js');module.import('../../api/evenements/methods.js');module.import('../../api/evenements/server/publications.js');module.import('../../api/users/server/publications.js');module.import('../../api/users/methods.js');module.import('../../api/images/server/publications.js');module.import('../../api/images/methods.js');
                                                                                                                     // 2
                                                                                                                     //
                                                                                                                     // 4
                                                                                                                     // 5
                                                                                                                     //
                                                                                                                     // 8
                                                                                                                     // 9
                                                                                                                     //
                                                                                                                     // 11
                                                                                                                     // 12
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"browser-policy.js":["meteor/browser-policy-common",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/browser-policy.js                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var BrowserPolicy;module.import('meteor/browser-policy-common',{"BrowserPolicy":function(v){BrowserPolicy=v}});      // 1
BrowserPolicy.content.allowFontDataUrl();                                                                            // 2
BrowserPolicy.content.allowOriginForAll('fonts.googleapis.com');                                                     // 3
BrowserPolicy.content.allowOriginForAll('https://fonts.gstatic.com');                                                // 4
// e.g., BrowserPolicy.content.allowOriginForAll( 's3.amazonaws.com' );                                              //
//https://fonts.googleapis.com/css?family=Roboto:400,300,500                                                         //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"configureServices.js":["../../modules/configure-services.js",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/configureServices.js                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.import('../../modules/configure-services.js');                                                                // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"envoiMail.js":["../../modules/envoiMail.js",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/envoiMail.js                                                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.import('../../modules/envoiMail.js');                                                                         // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"fixtures.js":["meteor/meteor","meteor/alanning:roles","meteor/accounts-base",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/fixtures.js                                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Roles;module.import('meteor/alanning:roles',{"Roles":function(v){Roles=v}});var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     //
var users = [{                                                                                                       // 5
  email: 'admin@admin.com',                                                                                          // 6
  password: 'Ar22ni38',                                                                                              // 7
  profile: {                                                                                                         // 8
    prenom: 'Carl',                                                                                                  // 9
    nom: 'Winslow'                                                                                                   // 10
  },                                                                                                                 // 8
  roles: ['admin']                                                                                                   // 12
}];                                                                                                                  // 5
                                                                                                                     //
users.forEach(function (_ref) {                                                                                      // 15
  var email = _ref.email;                                                                                            // 15
  var password = _ref.password;                                                                                      // 15
  var profile = _ref.profile;                                                                                        // 15
  var roles = _ref.roles;                                                                                            // 15
                                                                                                                     //
  var userExists = Meteor.users.findOne({ 'emails.address': email });                                                // 16
                                                                                                                     //
  if (!userExists) {                                                                                                 // 18
    var userId = Accounts.createUser({ email: email, password: password, profile: profile });                        // 19
    Roles.addUsersToRoles(userId, roles);                                                                            // 20
  }                                                                                                                  // 21
});                                                                                                                  // 22
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./accounts/email-templates","./browser-policy","./fixtures","./api","./configureServices","./onCreateUser","./envoiMail",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/index.js                                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.import('./accounts/email-templates');module.import('./browser-policy');module.import('./fixtures');module.import('./api');module.import('./configureServices');module.import('./onCreateUser');module.import('./envoiMail');
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     // 4
                                                                                                                     // 5
                                                                                                                     // 6
                                                                                                                     // 7
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"onCreateUser.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/onCreateUser.js                                                                            //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// une erreur est jetée dans l'environnement dev, il faut préciser ROOT_URL dans le déploiement en production        //
Accounts.onCreateUser(function (options, user) {                                                                     // 2
    if (Meteor.userId()) {                                                                                           // 3
        var service = _.keys(user.services)[0];                                                                      // 4
                                                                                                                     //
        var serviceToAdd = user.services;                                                                            // 6
        var existingUser = Meteor.user();                                                                            // 7
                                                                                                                     //
        user = existingUser;                                                                                         // 9
        user.services[service] = serviceToAdd[service];                                                              // 10
                                                                                                                     //
        Meteor.users.remove({ _id: existingUser._id });                                                              // 12
    } else {                                                                                                         // 14
        if (options.profile) user.profile = options.profile;                                                         // 16
    }                                                                                                                // 18
                                                                                                                     //
    return user;                                                                                                     // 20
});                                                                                                                  // 21
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"modules":{"configure-services.js":["meteor/service-configuration",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/modules/configure-services.js                                                                             //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var ServiceConfiguration;module.import('meteor/service-configuration',{"ServiceConfiguration":function(v){ServiceConfiguration=v}});
                                                                                                                     //
var services = Meteor.settings['private'].oAuth;                                                                     // 4
                                                                                                                     //
var configure = function configure() {                                                                               // 7
                                                                                                                     //
  if (services) {                                                                                                    // 9
    for (var service in services) {                                                                                  // 10
      ServiceConfiguration.configurations.upsert({ service: service }, {                                             // 11
        $set: services[service]                                                                                      // 12
      });                                                                                                            // 11
    }                                                                                                                // 14
  }                                                                                                                  // 15
};                                                                                                                   // 16
                                                                                                                     //
configure();                                                                                                         // 18
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"envoiMail.js":["meteor/aldeed:simple-schema","meteor/mdg:validated-method","../api/users/users.js","../api/evenements/evenements.js","meteor/email",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/modules/envoiMail.js                                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({envoiEmailConfirmation:function(){return envoiEmailConfirmation}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});var Users;module.import('../api/users/users.js',{"Users":function(v){Users=v}});var Evenements;module.import('../api/evenements/evenements.js',{"Evenements":function(v){Evenements=v}});var Email;module.import('meteor/email',{"Email":function(v){Email=v}});
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     // 4
                                                                                                                     // 5
                                                                                                                     // 6
                                                                                                                     //
var envoiEmailConfirmation = new ValidatedMethod({                                                                   // 8
  name: 'inscriptions.mailConfirmation',                                                                             // 9
  validate: new SimpleSchema({                                                                                       // 10
    userId: { type: String },                                                                                        // 11
    eveId: { type: String }                                                                                          // 12
  }).validator(),                                                                                                    // 10
  run: function run(_ref) {                                                                                          // 14
    var userId = _ref.userId;                                                                                        // 14
    var eveId = _ref.eveId;                                                                                          // 14
                                                                                                                     //
    if (Meteor.isServer) {                                                                                           // 15
      var recapCreneaux;                                                                                             // 15
                                                                                                                     //
      (function () {                                                                                                 // 15
        recapCreneaux = "";                                                                                          // 16
                                                                                                                     //
        var userData = Users.findOne({ _id: userId });                                                               // 17
        var famille = userData.famille;                                                                              // 18
        var mail = userData.emails;                                                                                  // 19
        console.log(mail[0].address);                                                                                // 20
                                                                                                                     //
        var evenement = Evenements.findOne({ _id: eveId });                                                          // 22
        var creneaux = evenement.creneaux;                                                                           // 23
                                                                                                                     //
        famille.map(function (membre) {                                                                              // 25
                                                                                                                     //
          creneaux.map(function (creneau) {                                                                          // 27
            if (creneau.inscrits.length > 0) {                                                                       // 28
              var trouveMembre = function trouveMembre(inscrit) {                                                    // 29
                return inscrit === membre._id;                                                                       // 30
              };                                                                                                     // 31
              var indexInscrit = creneau.inscrits.findIndex(trouveMembre);                                           // 32
              if (indexInscrit >= 0) {                                                                               // 33
                recapCreneaux += "<p>" + membre.prenom + " est inscrit-e sur le creneau" + creneau.horaire + "</p>";
              }                                                                                                      // 35
            }                                                                                                        // 36
          });                                                                                                        // 37
        });                                                                                                          // 38
        console.log("preparation terminée");                                                                         // 39
        var leTexte = Assets.getText('emailRecapInscriptions.html');                                                 // 40
        console.log(leTexte);                                                                                        // 41
                                                                                                                     //
        var html = leTexte.replace("{{lesInscriptions}}", recapCreneaux);                                            // 43
                                                                                                                     //
        Email.send({                                                                                                 // 45
          to: userData.emails[0].address,                                                                            // 46
          from: "lasalledesmachines@labonnefabrique.fr",                                                             // 47
          subject: "Détails de vos inscriptions",                                                                    // 48
          html: html                                                                                                 // 49
        });                                                                                                          // 45
      })();                                                                                                          // 15
    }                                                                                                                // 52
  }                                                                                                                  // 54
});                                                                                                                  // 8
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"main.js":["/imports/startup/server",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/main.js                                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.import('/imports/startup/server');                                                                            // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
